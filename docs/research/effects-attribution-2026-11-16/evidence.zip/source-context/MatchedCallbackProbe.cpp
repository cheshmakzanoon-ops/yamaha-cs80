// Diagnostic scaffold: qualification must pass before interpreting timing.
#include "plugin/PluginProcessor.h"
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <time.h>
#include <xmmintrin.h>

namespace {
constexpr int frames=128, windows=256;
using Stereo=std::array<float,frames*2>;
std::uint64_t now() {
    timespec t{};
    if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t)) throw std::runtime_error("thread clock failed");
    return std::uint64_t(t.tv_sec)*1000000000ULL+std::uint64_t(t.tv_nsec);
}
std::uint32_t bits(float x) {std::uint32_t y;std::memcpy(&y,&x,4);return y;}
void compare(const juce::AudioBuffer<float>& a,const Stereo& b,int window) {
    for(int f=0;f<frames;++f) for(int c=0;c<2;++c) {
        const float x=a.getSample(c,f), y=b[std::size_t(2*f+c)];
        if(!std::isfinite(x)||!std::isfinite(y)||bits(x)!=bits(y)) {
            std::cerr<<"FIRST_MISMATCH window="<<window<<" frame="<<f<<" channel="<<c
                <<" processor_bits="<<bits(x)<<" core_bits="<<bits(y)<<" mxcsr="<<_mm_getcsr()<<'\n';
            throw std::runtime_error("exact output mismatch; no cost interpretation");
        }
    }
}
void flatten(const juce::AudioBuffer<float>& a,Stereo& b) {
    for(int f=0;f<frames;++f) for(int c=0;c<2;++c) b[std::size_t(2*f+c)]=a.getSample(c,f);
}
template<class T> bool same(const T& a,const T& b) { return std::memcmp(&a,&b,sizeof(T))==0; }
template<class T,std::size_t N> bool same(const std::array<T,N>& a,const std::array<T,N>& b) {
    for(std::size_t i=0;i<N;++i) if(!same(a[i],b[i])) return false;
    return true;
}
void readouts(const cs80::Engine& a,const cs80::Engine& b) {
    for(int rank=0;rank<2;++rank) {
        const auto sa=a.getSourceToneInfo(rank),sb=b.getSourceToneInfo(rank);
        if(sa.selector!=0 || sb.selector!=0 || sa.route!=sb.route ||
           sa.route!=cs80::source_factory::route(rank,0,true) ||
           sa.provenance.version!=cs80::source_factory::modelVersion ||
           sb.provenance.version!=cs80::source_factory::modelVersion ||
           sa.provenance.sourceHash!=cs80::source_factory::sourceFingerprint ||
           sb.provenance.sourceHash!=cs80::source_factory::sourceFingerprint)
            throw std::runtime_error("unexpected source selector/route/model");
        const auto x=a.getSourceCutoffReadout(rank),y=b.getSourceCutoffReadout(rank);
        if(!same(x.pinVolts,y.pinVolts)||!same(x.effectiveCv,y.effectiveCv)||
           !same(x.loadedBusVolts,y.loadedBusVolts)||x.saturatedVoices!=y.saturatedVoices)
            throw std::runtime_error("named cutoff readout mismatch");
    }
    const auto x=a.getSourceSharedReadout(),y=b.getSourceSharedReadout();
    if(!same(x.qVolts,y.qVolts)||!same(x.q,y.q)||!same(x.levelPinVolts,y.levelPinVolts)||
       !same(x.levelGain,y.levelGain)||!same(x.qBusVolts,y.qBusVolts)||
       !same(x.levelBusVolts,y.levelBusVolts)||!same(x.masterResVolts,y.masterResVolts)||
       x.saturatedVoices!=y.saturatedVoices||x.masterResSaturated!=y.masterResSaturated)
        throw std::runtime_error("named shared readout mismatch");
    for(int m=0;m<cs80::modern::kMsegCount;++m) {
        if(!same(a.getModernMsegDisplayPosition(m),b.getModernMsegDisplayPosition(m)))
            throw std::runtime_error("MSEG display position mismatch");
        for(int v=0;v<8;++v) if(!same(a.getModernMsegValue(v,m),b.getModernMsegValue(v,m)))
            throw std::runtime_error("MSEG value mismatch");
    }
}
void setup(Cs80AudioProcessor& p) {
    auto layout=p.getBusesLayout();
    if(!layout.inputBuses.isEmpty()) layout.inputBuses.set(0,juce::AudioChannelSet::disabled());
    if(!p.setBusesLayout(layout) || p.getTotalNumInputChannels()!=0)
        throw std::runtime_error("input bus not disabled");
    p.setParamValue(cs80::P_mpeOn,0);
    p.setEngineMode(Cs80AudioProcessor::EngineMode::circuit);
    p.setParamValue(cs80::P_parityMode,0);
    p.setParamValue(cs80::P_voiceMode,0);
    p.setParamValue(cs80::P_arpOn,0);
    p.setParamValue(cs80::P_tuningMode,0);
    p.setParamValue(cs80::P_oversampling,0);
    p.selectHardwareSource(0,0);p.selectHardwareSource(1,0);
    p.setNonRealtime(false);
    p.prepareToPlay(48000.,frames);
}
}
int main(int argc,char** argv) try {
    if(argc!=3 || (std::strcmp(argv[2],"aa") && std::strcmp(argv[2],"core")))
        throw std::runtime_error("provide NEW output CSV path and aa|core mode; launch requires coordination");
    const bool aa=std::strcmp(argv[2],"aa")==0;
    if(juce::File(argv[1]).exists()) throw std::runtime_error("refuse existing output");
    juce::ScopedJuceInitialiser_GUI init;
    juce::TemporaryFile storeA("-matched-callback-a"),storeB("-matched-callback-b");
    auto a=std::make_unique<Cs80AudioProcessor>(storeA.getFile());
    auto b=std::make_unique<Cs80AudioProcessor>(storeB.getFile());
    setup(*a);setup(*b);
    juce::AudioBuffer<float> audioA(2,frames),audioB(2,frames);
    juce::MidiBuffer midiA,midiB; midiA.ensureSize(4096);midiB.ensureSize(4096);
    Stereo direct{};
    // Identical real callbacks establish wrapper-controlled state in both owners.
    for(int i=0;i<34;++i) {
        audioA.clear();audioB.clear();midiA.clear();midiB.clear();
        if(i==1) for(int n=0;n<8;++n) {
            auto m=juce::MidiMessage::noteOn(1,48+n,juce::uint8(100));
            midiA.addEvent(m,0);midiB.addEvent(m,0);
        }
        a->processBlock(audioA,midiA);b->processBlock(audioB,midiB);
        flatten(audioB,direct);compare(audioA,direct,-34+i);
    }
    auto& ea=a->getEngine(); auto& eb=b->getEngine();
    if(ea.getOversamplingFactor()!=eb.getOversamplingFactor() ||
       ea.getInternalSampleRate()!=eb.getInternalSampleRate() ||
       ea.getRenderPolicy()!=eb.getRenderPolicy() ||
       ea.getLatencySamples()!=eb.getLatencySamples()) throw std::runtime_error("workload metadata mismatch");
    if(ea.getRenderPolicy()!=cs80::RenderPolicy::sourcePerformance ||
       eb.getRenderPolicy()!=cs80::RenderPolicy::sourcePerformance ||
       ea.getOversamplingFactor()!=2 || eb.getOversamplingFactor()!=2 ||
       ea.getInternalSampleRate()!=96000. || eb.getInternalSampleRate()!=96000.)
        throw std::runtime_error("expected circuit/sourcePerformance 2x/96k workload");
    readouts(ea,eb);
    if(ea.isMpeEnabled() || eb.isMpeEnabled()) throw std::runtime_error("unexpected MPE");
    std::ofstream csv(argv[1]); if(!csv) throw std::runtime_error("output open failed");
    csv<<"window,order,processor_thread_ns,core_thread_ns,host_rate,frames,actual_factor,internal_rate\n";
    midiA.clear();midiB.clear();
    // Same denormal controls for both branches; native processor scope nests inside.
    juce::ScopedNoDenormals fp;
    for(int w=0;w<windows;++w) {
        audioA.clear();audioB.clear();direct.fill(0);
        std::uint64_t pa{},pb{};
        const auto mode=_mm_getcsr() & ~0x3fu;
        auto processor=[&]{auto t=now();a->processBlock(audioA,midiA);pa=now()-t;
            if((_mm_getcsr() & ~0x3fu)!=mode) throw std::runtime_error("processor FP control changed");};
        auto core=[&]{auto t=now();
            if(aa) b->processBlock(audioB,midiB); else eb.render(direct.data(),frames);
            pb=now()-t;
            if((_mm_getcsr() & ~0x3fu)!=mode) throw std::runtime_error("core FP control changed");};
        if(w%2) {core();processor();} else {processor();core();}
        if(aa) flatten(audioB,direct);
        if(!pa||!pb) throw std::runtime_error("zero duration");
        compare(audioA,direct,w);
        readouts(ea,eb);
        int active=0;
        for(int v=0;v<8;++v) {
            const auto va=ea.getVoiceInfo(v), vb=eb.getVoiceInfo(v);
            active+=va.active;
            if(va.active!=vb.active || va.held!=vb.held || va.pedalHeld!=vb.pedalHeld ||
               va.note!=vb.note || va.channel!=vb.channel)
                throw std::runtime_error("voice control state mismatch");
        }
        if(active!=8) throw std::runtime_error("not eight active voices");
        if(ea.getControlFrameStatus()!=cs80::Engine::ControlFrameStatus::accepted ||
           eb.getControlFrameStatus()!=cs80::Engine::ControlFrameStatus::accepted ||
           ea.getOversamplingFactor()!=eb.getOversamplingFactor() ||
           ea.getInternalSampleRate()!=eb.getInternalSampleRate())
            throw std::runtime_error("live control/rate mismatch");
        csv<<w<<','<<(w%2?"BA":"AB")<<','<<pa<<','<<pb<<",48000,128,"
           <<ea.getOversamplingFactor()<<','<<ea.getInternalSampleRate()<<'\n';
    }
    csv.flush(); if(!csv) throw std::runtime_error("output write failed");
    std::cout<<"EXACT_HELD_SCOPE_PASS mode="<<argv[2]<<" windows="<<windows<<" factor="<<ea.getOversamplingFactor()
        <<" internal_rate="<<ea.getInternalSampleRate()<<'\n';
    return 0;
} catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
