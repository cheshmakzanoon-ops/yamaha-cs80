// Reuse reviewed setup and primitive named-state assertions, not its timing loop.
#define main unusedMatchedProbeMain
#include "../callback-protocol/MatchedCallbackProbe.cpp"
#undef main
#include <valgrind/callgrind.h>
#include <valgrind/valgrind.h>
#include <vector>
namespace {
std::vector<unsigned char>state;
template<class T>void put(const T& x){const auto* p=reinterpret_cast<const unsigned char*>(&x);state.insert(state.end(),p,p+sizeof x);}
void capture(const cs80::Engine& e){
 put(e.activeVoices());put(e.getOversamplingFactor());put(e.getInternalSampleRate());put(e.getControlFrameStatus());
 for(int v=0;v<8;++v){const auto vi=e.getVoiceInfo(v);put(vi.active);put(vi.held);put(vi.pedalHeld);put(vi.note);put(vi.channel);
  for(int r=0;r<2;++r){const auto& s=e.getRankOscillatorState(v,r);
   for(double x:{s.charge,s.resetRemainingSeconds,s.inputBaselineVolts,s.triangleBaselineVolts,s.heldFrequencyHz,s.heldThresholdVolts,s.elapsedSeconds})put(x);
   put(s.sawEnabled);put(s.pulseEnabled);put(s.residualCursor);put(s.resetCount);
   for(const auto& b:s.residual)for(double x:b)put(x);
   const auto a=e.getRankAudioState(v,r);const auto n=e.getRankEnvelopeState(v,r);const auto i=e.getRankInfo(v,r);
   for(float x:{a.phase,a.hpf.ic1,a.hpf.ic2,a.lpf.ic1,a.lpf.ic2,n.amplitude.value,n.amplitude.elapsed,n.filter.value,n.filter.elapsed,i.hpfHz,i.lpfHz,i.hpfQ,i.lpfQ,i.oscillatorHz,i.keyVolts})put(x);
   put(n.amplitude.stage);put(n.filter.stage);
  }
 }
 for(int r=0;r<2;++r){const auto c=e.getSourceCutoffReadout(r);for(int v=0;v<8;++v)for(int s=0;s<2;++s){put(c.pinVolts[v][s]);put(c.effectiveCv[v][s]);}for(double x:c.loadedBusVolts)put(x);put(c.saturatedVoices);}
 const auto q=e.getSourceSharedReadout();for(int r=0;r<2;++r)for(int v=0;v<8;++v){for(int s=0;s<2;++s){put(q.qVolts[r][v][s]);put(q.q[r][v][s]);}put(q.levelPinVolts[r][v]);put(q.levelGain[r][v]);}for(const auto& rank:q.qBusVolts)for(double x:rank)put(x);for(double x:q.levelBusVolts)put(x);put(q.masterResVolts);put(q.saturatedVoices);put(q.masterResSaturated);
}
}


int main(int argc,char** argv) try {
    if(argc!=2)
        throw std::runtime_error("provide new output binary");
    if(juce::File(argv[1]).exists()) throw std::runtime_error("refuse existing output");
    juce::ScopedJuceInitialiser_GUI init;
    juce::TemporaryFile store("-callgrind-callback");
    auto owner=std::make_unique<Cs80AudioProcessor>(store.getFile());
    setup(*owner);
    using namespace cs80;
    owner->setParamValue(P_fx1Model,0);owner->setParamValue(P_fx2Model,0);owner->setParamValue(P_fx3Model,0);
    owner->setParamValue(P_fx1Type,1);owner->setParamValue(P_fx1Mix,.20f);
    owner->setParamValue(P_fx2Type,4);owner->setParamValue(P_fx2Mix,.15f);
    owner->setParamValue(P_fx3Type,0);owner->setParamValue(P_fx3Mix,0);owner->setParamValue(P_chorusOn,0);
    auto verifyFx=[&](){const auto& p=owner->getEngine().getParams();
      if(p[P_fx1Model]!=0||p[P_fx2Model]!=0||p[P_fx3Model]!=0||p[P_fx1Type]!=1||p[P_fx2Type]!=4||p[P_fx3Type]!=0||p[P_fx1Mix]!=.20f||p[P_fx2Mix]!=.15f||p[P_fx3Mix]!=0||p[P_chorusOn]!=0)throw std::runtime_error("unexpected FX configuration");};
    juce::AudioBuffer<float> audio(2,frames);
    juce::MidiBuffer midi;midi.ensureSize(4096);
    for(int i=0;i<750;++i) {
        audio.clear();midi.clear();
        if(i==1) for(int n=0;n<8;++n) midi.addEvent(juce::MidiMessage::noteOn(1,48+n,juce::uint8(100)),0);
        owner->processBlock(audio,midi);
    }
    auto& e=owner->getEngine();
    if(e.getRenderPolicy()!=cs80::RenderPolicy::sourcePerformance || e.getOversamplingFactor()!=2 ||
       e.getInternalSampleRate()!=96000.) throw std::runtime_error("unexpected execution mode");
    readouts(e,e);verifyFx();
    std::array<Stereo,16> output{};
    std::array<unsigned,16> status{};state.reserve(500000);
    std::cout<<"case=chorus-reverb-held"<<" valgrind="<<RUNNING_ON_VALGRIND
        <<" avx2="<<bool(__builtin_cpu_supports("avx2"))<<" fma="<<bool(__builtin_cpu_supports("fma"))
        <<" mxcsr="<<_mm_getcsr()<<" factor=2 internal_rate=96000 frames=128 windows=16"
        <<" modWheelVcf="<<e.getParams()[cs80::P_modWheelVcf]
        <<" modWheelSub="<<e.getParams()[cs80::P_modWheelSub]<<'\n';
    CALLGRIND_START_INSTRUMENTATION;
    CALLGRIND_ZERO_STATS;
    for(int w=0;w<16;++w) {
        audio.clear();midi.clear();
        _mm_setcsr(0x1f80);const auto mode=_mm_getcsr() & ~0x3fu;
        CALLGRIND_TOGGLE_COLLECT;
        owner->processBlock(audio,midi);
        CALLGRIND_TOGGLE_COLLECT;
        status[w]=_mm_getcsr();
        if((status[w] & ~0x3fu)!=mode) throw std::runtime_error("FP mode changed");
        flatten(audio,output[std::size_t(w)]);
        for(float sample:output[std::size_t(w)]) if(!std::isfinite(sample)) throw std::runtime_error("nonfinite output");
        int active=0;for(int v=0;v<8;++v) active+=e.getVoiceInfo(v).active;
        if(active!=8) throw std::runtime_error("voice count changed");
        readouts(e,e);verifyFx();capture(e);
        for(auto id:{P_fx1Model,P_fx2Model,P_fx3Model,P_fx1Type,P_fx2Type,P_fx3Type,P_fx1Mix,P_fx2Mix,P_fx3Mix,P_chorusOn})put(e.getParams()[id]);
        std::cout<<"window="<<w<<" active="<<active<<" fx=1:.20,4:.15,0:0"<<'\n';
    }
    CALLGRIND_DUMP_STATS;
    CALLGRIND_STOP_INSTRUMENTATION;
    std::ofstream file(argv[1],std::ios::binary);
    file.write(reinterpret_cast<const char*>(output.data()),sizeof(output));file.flush();
    if(!file) throw std::runtime_error("output write failed");
    std::ofstream sf(std::string(argv[1])+".state",std::ios::binary);sf.write(reinterpret_cast<const char*>(state.data()),state.size());sf.flush();
    std::ofstream st(std::string(argv[1])+".status",std::ios::binary);st.write(reinterpret_cast<const char*>(status.data()),sizeof status);st.flush();
    if(!sf||!st)throw std::runtime_error("snapshot write failed");
    std::cout<<"PASS measured_callbacks=16 audio_bytes="<<sizeof(output)<<'\n';
    return 0;
} catch(const std::exception& ex) {std::cerr<<ex.what()<<'\n';return 1;}
