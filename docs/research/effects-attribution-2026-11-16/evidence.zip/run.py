from pathlib import Path
import subprocess,json,hashlib,os,struct,re,traceback
r=Path(__file__).resolve().parent.parent;d=Path(__file__).resolve().parent;b=r/'plugin-build'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def job(name,cmd,cwd=b):
 (d/(name+'.command.json')).write_text(json.dumps(list(map(str,cmd)),indent=2)+'\n')
 with (d/(name+'.log')).open('w') as f:x=subprocess.run(list(map(str,cmd)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 (d/(name+'.exit')).write_text(str(x.returncode)+'\n');assert x.returncode==0,name
try:
 assert not (d/'probe').exists(),'no reruns/overwrite'
 cmd=json.loads((r/'callback-protocol/compile-command.json').read_text());cmd[cmd.index('-o')+1]=str(d/'probe.o');cmd[cmd.index('-c')+1]=str(d/'Probe.cpp')
 link=json.loads((r/'callgrind-debug/link-command.json').read_text());old=str(r/'callgrind-protocol/probe.o');assert link.count(old)==1;link[link.index(old)]=str(d/'probe.o');link[link.index('-o')+1]=str(d/'probe')
 inputs=[d/'Probe.cpp',d/'PROTOCOL.md',d/'run.py',r/'callback-protocol/MatchedCallbackProbe.cpp']+[(Path(x) if Path(x).is_absolute() else b/x) for x in link if x.endswith('.a')]
 frozen={str(p):sha(p) for p in inputs};(d/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
 job('compile',['taskset','-c','5',*cmd]);job('link',['taskset','-c','5',*link])
 vg=r/'deps/sysroot/usr/bin/valgrind'
 for mode in ['native','vg']:
  out=d/(mode+'.bin');assert not out.exists();cmd=['taskset','-c','5']
  if mode=='vg':cmd += [str(vg),'--tool=callgrind','--instr-atstart=no','--collect-atstart=no','--cache-sim=no','--branch-sim=no','--dump-instr=yes','--error-exitcode=99','--extra-debuginfo-path='+os.environ['VALGRIND_DEBUGINFO'],'--log-file='+str(d/'vg.vglog'),'--callgrind-out-file='+str(d/'vg.out')]
  job(mode,cmd+[d/'probe',out])
 for suffix in ['.bin','.bin.state']:
  a=(d/('native'+suffix)).read_bytes();z=(d/('vg'+suffix)).read_bytes();assert a==z,(suffix,'parity failure')
 assert (d/'native.bin').stat().st_size==16384
 status=[struct.unpack('16I',(d/(x+'.bin.status')).read_bytes()) for x in ['native','vg']]
 assert all((a&~63)==(z&~63)==0x1f80 for a,z in zip(*status))
 logs=[(d/(x+'.log')).read_text() for x in ['native','vg']]
 for log in logs:assert re.findall(r'window=(\d+) active=(\d+)',log)==[(str(i),'8') for i in range(16)]
 assert re.findall(r'avx2=(\d+) fma=(\d+)',logs[0])==re.findall(r'avx2=(\d+) fma=(\d+)',logs[1])
 raw=(d/'vg.out.1').read_text();assert 'Ig00156BatchAccess' in raw
 ann=r/'deps/sysroot/usr/bin/callgrind_annotate'
 for inc in ['yes','no']:job('inclusive-'+inc,[ann,'--inclusive='+inc,'--tree=both','--threshold=100',d/'vg.out.1'])
 for p,h in frozen.items():assert sha(Path(p))==h
 (d/'PARITY.json').write_text(json.dumps({'PCM_sha256':sha(d/'native.bin'),'named_state_sha256':sha(d/'native.bin.state'),'status_deltas':[a^z for a,z in zip(*status)],'Ir':int(re.search(r'^summary: (\d+)',raw,re.M).group(1)),'executed_FX_path_audit':'pending actual call-edge review, not inferred from configuration'},indent=2)+'\n')
except BaseException:(d/'FAILED.txt').write_text(traceback.format_exc());(d/'run.exit').write_text('1\n');raise
else:(d/'run.exit').write_text('0\n')
